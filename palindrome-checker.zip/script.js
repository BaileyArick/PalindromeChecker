const input = document.getElementById('text-input');
const checkBtn = document.getElementById('check-btn');
const result = document.getElementById('result');

checkBtn.addEventListener('click', () => {
    isPalindrome(input.value);
});

function isPalindrome(text){
    text = text.toLowerCase();
    let textLength = text.length;
    for(i = 0; i <= textLength/2; i++){
        if( text[i] !== text[textLength-i-1] ){
            result.innerText = `${input.value} is not a palindrome!`;
            return false;
        }
    }
    result.innerText = `${input.value} is a palindrome!`;
    return true;
}